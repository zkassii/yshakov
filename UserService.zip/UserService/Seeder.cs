using Microsoft.Extensions.Options;

namespace UserService;

// Сидер для тестирования: создаёт пользователей, публикует user.registered
// и (опционально) шлёт тестовые order.created, чтобы проверить consumer.
public class Seeder : IHostedService
{
    private readonly IConfiguration _config;
    private readonly UserStore _store;
    private readonly IEventPublisher _producer;
    private readonly KafkaOptions _options;
    private readonly ILogger<Seeder> _logger;

    public Seeder(IConfiguration config, UserStore store, IEventPublisher producer,
        IOptions<KafkaOptions> options, ILogger<Seeder> logger)
    {
        _config = config;
        _store = store;
        _producer = producer;
        _options = options.Value;
        _logger = logger;
    }

    public async Task StartAsync(CancellationToken ct)
    {
        if (!_config.GetValue<bool>("Seed:Enabled")) return;

        var requests = new[]
        {
            new UserRequest("Иван Петров", "ivan@example.com", "+79001112233"),
            new UserRequest("Мария Сидорова", "maria@example.com", "+79004445566"),
            new UserRequest("Алексей Смирнов", "alex@example.com", null),
        };

        try
        {
            foreach (var r in requests)
            {
                var user = _store.Add(r);
                await _producer.PublishAsync(_options.ProduceTopic, user.Id.ToString(),
                    new UserRegisteredEvent(user.Id, user.Name, user.Email, user.Phone, user.RegisteredAt));
            }

            if (_config.GetValue<bool>("Seed:PublishTestOrders"))
            {
                var rnd = new Random();
                for (var i = 1; i <= 5; i++)
                {
                    var order = new OrderCreatedEvent(i, rnd.Next(1, 4), $"Товар-{rnd.Next(1, 100)}", rnd.Next(1, 5), 1500, DateTime.UtcNow);
                    await _producer.PublishAsync(_options.ConsumeTopic, order.OrderId.ToString(), order);
                }
            }

            _logger.LogInformation("Сидер выполнен");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Сидер не смог отправить данные в Kafka");
        }
    }

    public Task StopAsync(CancellationToken ct) => Task.CompletedTask;
}
