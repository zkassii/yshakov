using UserService;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<KafkaOptions>(builder.Configuration.GetSection("Kafka"));
builder.Services.AddSingleton<UserStore>();
builder.Services.AddSingleton<IEventPublisher, KafkaProducer>();
builder.Services.AddHostedService<OrderCreatedConsumer>(); // Consumer: order.created
builder.Services.AddHostedService<Seeder>();               // тестовые данные

var app = builder.Build();

// регистрация пользователя + публикация user.registered
app.MapPost("/users", async (UserRequest req, UserStore store, IEventPublisher producer, Microsoft.Extensions.Options.IOptions<KafkaOptions> opt) =>
{
    if (string.IsNullOrWhiteSpace(req.Name) || string.IsNullOrWhiteSpace(req.Email))
        return Results.BadRequest("Name и Email обязательны");

    var user = store.Add(req);
    await producer.PublishAsync(opt.Value.ProduceTopic, user.Id.ToString(),
        new UserRegisteredEvent(user.Id, user.Name, user.Email, user.Phone, user.RegisteredAt));

    return Results.Created($"/users/{user.Id}", user);
});

// изменение данных пользователя
app.MapPut("/users/{id:int}", (int id, UserRequest req, UserStore store) =>
    store.Update(id, req) is { } user ? Results.Ok(user) : Results.NotFound());

// просмотр информации о пользователе
app.MapGet("/users/{id:int}", (int id, UserStore store) =>
    store.Get(id) is { } user ? Results.Ok(user) : Results.NotFound());

app.MapGet("/users", (UserStore store) => store.GetAll());

app.Run();

// нужен для WebApplicationFactory в тестах
public partial class Program { }
