using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using UserService;

namespace UserService.Tests;

// Фейковый publisher: вместо Kafka запоминает сообщения
public class FakePublisher : IEventPublisher
{
    public List<(string Topic, string Key, object Payload)> Sent { get; } = new();

    public Task PublishAsync<T>(string topic, string key, T payload)
    {
        lock (Sent) Sent.Add((topic, key, payload!));
        return Task.CompletedTask;
    }
}

public class TestFactory : WebApplicationFactory<Program>
{
    public FakePublisher Publisher { get; } = new();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseSetting("Seed:Enabled", "false");

        builder.ConfigureServices(services =>
        {
            services.RemoveAll<IEventPublisher>();
            services.AddSingleton<IEventPublisher>(Publisher);

            // отключаем consumer и сидер, чтобы не ходить в Kafka
            services.RemoveAll<IHostedService>();
        });
    }
}

public class ApiTests : IClassFixture<TestFactory>
{
    private readonly TestFactory _factory;
    private readonly HttpClient _client;

    public ApiTests(TestFactory factory)
    {
        _factory = factory;
        _client = factory.CreateClient();
    }

    [Fact]
    public async Task PostUser_Returns201_AndPublishesUserRegistered()
    {
        var response = await _client.PostAsJsonAsync("/users", new UserRequest("Иван", "ivan@test.ru", "+7900"));

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var user = await response.Content.ReadFromJsonAsync<User>();
        Assert.NotNull(user);
        Assert.Equal("Иван", user!.Name);

        var sent = _factory.Publisher.Sent.Last(s => s.Topic == "user.registered");
        Assert.Equal(user.Id.ToString(), sent.Key);
        var evt = Assert.IsType<UserRegisteredEvent>(sent.Payload);
        Assert.Equal(user.Id, evt.UserId);
        Assert.Equal("ivan@test.ru", evt.Email);
    }

    [Theory]
    [InlineData("", "a@b.ru")]
    [InlineData("Иван", "")]
    [InlineData("  ", "  ")]
    public async Task PostUser_Returns400_WhenInvalid(string name, string email)
    {
        var before = _factory.Publisher.Sent.Count;

        var response = await _client.PostAsJsonAsync("/users", new UserRequest(name, email, null));

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal(before, _factory.Publisher.Sent.Count); // событие не отправлено
    }

    [Fact]
    public async Task GetUser_ReturnsUser_AfterCreate()
    {
        var created = await (await _client.PostAsJsonAsync("/users", new UserRequest("Мария", "m@test.ru", null)))
            .Content.ReadFromJsonAsync<User>();

        var response = await _client.GetAsync($"/users/{created!.Id}");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var user = await response.Content.ReadFromJsonAsync<User>();
        Assert.Equal("Мария", user!.Name);
    }

    [Fact]
    public async Task GetUser_Returns404_WhenMissing()
    {
        var response = await _client.GetAsync("/users/99999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task PutUser_UpdatesData()
    {
        var created = await (await _client.PostAsJsonAsync("/users", new UserRequest("Алексей", "a@test.ru", null)))
            .Content.ReadFromJsonAsync<User>();

        var response = await _client.PutAsJsonAsync($"/users/{created!.Id}",
            new UserRequest("Алексей Новый", "new@test.ru", "+7911"));

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var updated = await response.Content.ReadFromJsonAsync<User>();
        Assert.Equal("Алексей Новый", updated!.Name);
        Assert.Equal("new@test.ru", updated.Email);
    }

    [Fact]
    public async Task PutUser_Returns404_WhenMissing()
    {
        var response = await _client.PutAsJsonAsync("/users/99999", new UserRequest("X", "x@x.ru", null));

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task GetUsers_ReturnsList()
    {
        await _client.PostAsJsonAsync("/users", new UserRequest("Список", "l@test.ru", null));

        var users = await _client.GetFromJsonAsync<List<User>>("/users");

        Assert.NotNull(users);
        Assert.NotEmpty(users!);
    }
}
