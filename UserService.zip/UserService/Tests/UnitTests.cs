using System.Text.Json;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using UserService;

namespace UserService.Tests;

public class UserStoreTests
{
    private static UserRequest Req(string name = "Иван", string email = "ivan@test.ru") => new(name, email, null);

    [Fact]
    public void Add_AssignsSequentialIds()
    {
        var store = new UserStore();

        var a = store.Add(Req());
        var b = store.Add(Req("Мария", "m@test.ru"));

        Assert.Equal(1, a.Id);
        Assert.Equal(2, b.Id);
        Assert.Equal(2, store.GetAll().Count());
    }

    [Fact]
    public void Get_ReturnsUser_WhenExists()
    {
        var store = new UserStore();
        var user = store.Add(Req());

        var found = store.Get(user.Id);

        Assert.NotNull(found);
        Assert.Equal("Иван", found!.Name);
    }

    [Fact]
    public void Get_ReturnsNull_WhenMissing()
    {
        Assert.Null(new UserStore().Get(999));
    }

    [Fact]
    public void Update_ChangesFields()
    {
        var store = new UserStore();
        var user = store.Add(Req());

        var updated = store.Update(user.Id, new UserRequest("Пётр", "p@test.ru", "+7900"));

        Assert.NotNull(updated);
        Assert.Equal("Пётр", updated!.Name);
        Assert.Equal("p@test.ru", updated.Email);
        Assert.Equal("+7900", updated.Phone);
    }

    [Fact]
    public void Update_ReturnsNull_WhenMissing()
    {
        Assert.Null(new UserStore().Update(42, Req()));
    }

    [Fact]
    public void IncrementOrders_IncreasesCounter()
    {
        var store = new UserStore();
        var user = store.Add(Req());

        Assert.True(store.IncrementOrders(user.Id));
        Assert.True(store.IncrementOrders(user.Id));

        Assert.Equal(2, store.Get(user.Id)!.OrdersCount);
    }

    [Fact]
    public void IncrementOrders_ReturnsFalse_WhenUserMissing()
    {
        Assert.False(new UserStore().IncrementOrders(7));
    }

    [Fact]
    public void IncrementOrders_IsThreadSafe()
    {
        var store = new UserStore();
        var user = store.Add(Req());

        Parallel.For(0, 1000, _ => store.IncrementOrders(user.Id));

        Assert.Equal(1000, store.Get(user.Id)!.OrdersCount);
    }
}

public class OrderCreatedConsumerTests
{
    private static (OrderCreatedConsumer consumer, UserStore store) Create()
    {
        var store = new UserStore();
        var consumer = new OrderCreatedConsumer(
            Options.Create(new KafkaOptions()), store, NullLogger<OrderCreatedConsumer>.Instance);
        return (consumer, store);
    }

    [Fact]
    public void ProcessMessage_CountsOrder_ForExistingUser()
    {
        var (consumer, store) = Create();
        var user = store.Add(new UserRequest("Иван", "i@test.ru", null));
        var json = $$"""{"orderId":10,"userId":{{user.Id}},"product":"Товар","quantity":2,"price":1500,"createdAt":"2026-11-20T10:00:00Z"}""";

        var handled = consumer.ProcessMessage(json);

        Assert.True(handled);
        Assert.Equal(1, store.Get(user.Id)!.OrdersCount);
    }

    [Fact]
    public void ProcessMessage_ReturnsFalse_ForUnknownUser()
    {
        var (consumer, _) = Create();
        var json = """{"orderId":1,"userId":999,"product":"X","quantity":1,"price":10,"createdAt":"2026-11-20T10:00:00Z"}""";

        Assert.False(consumer.ProcessMessage(json));
    }

    [Fact]
    public void ProcessMessage_ReturnsFalse_ForNullJson()
    {
        var (consumer, _) = Create();

        Assert.False(consumer.ProcessMessage("null"));
    }

    [Fact]
    public void ProcessMessage_Throws_ForInvalidJson()
    {
        var (consumer, _) = Create();

        Assert.ThrowsAny<JsonException>(() => consumer.ProcessMessage("это не json"));
    }
}

public class ContractTests
{
    [Fact]
    public void UserRegisteredEvent_SerializesToCamelCase()
    {
        var evt = new UserRegisteredEvent(1, "Иван", "i@test.ru", null,
            new DateTime(2026, 11, 20, 10, 0, 0, DateTimeKind.Utc));

        var json = JsonSerializer.Serialize(evt, new JsonSerializerOptions(JsonSerializerDefaults.Web));

        Assert.Contains("\"userId\":1", json);
        Assert.Contains("\"email\":\"i@test.ru\"", json);
        Assert.Contains("\"registeredAt\"", json);
    }
}
