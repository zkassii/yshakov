using System.Collections.Concurrent;

namespace UserService;

public class KafkaOptions
{
    public string BootstrapServers { get; set; } = "10.9.2.80:9092";
    public string GroupId { get; set; } = "user-service-group-2";
    public string ProduceTopic { get; set; } = "user.registered";
    public string ConsumeTopic { get; set; } = "order.created";
}

public class User
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string? Phone { get; set; }
    public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
    public int OrdersCount { get; set; }
}

// DTO для регистрации / изменения
public record UserRequest(string Name, string Email, string? Phone);

// ---- Контракты Kafka-сообщений (JSON, camelCase) ----

// Публикуем в топик user.registered
public record UserRegisteredEvent(int UserId, string Name, string Email, string? Phone, DateTime RegisteredAt);

// Читаем из топика order.created (формат согласовать с командой Order Service)
public record OrderCreatedEvent(int OrderId, int UserId, string Product, int Quantity, decimal Price, DateTime CreatedAt);

// Хранилище в памяти
public class UserStore
{
    private readonly ConcurrentDictionary<int, User> _users = new();
    private int _nextId;

    public User Add(UserRequest r)
    {
        var user = new User
        {
            Id = Interlocked.Increment(ref _nextId),
            Name = r.Name,
            Email = r.Email,
            Phone = r.Phone
        };
        _users[user.Id] = user;
        return user;
    }

    public User? Get(int id) => _users.TryGetValue(id, out var u) ? u : null;

    public IEnumerable<User> GetAll() => _users.Values.OrderBy(u => u.Id);

    public User? Update(int id, UserRequest r)
    {
        if (!_users.TryGetValue(id, out var u)) return null;
        u.Name = r.Name;
        u.Email = r.Email;
        u.Phone = r.Phone;
        return u;
    }

    public bool IncrementOrders(int userId)
    {
        if (!_users.TryGetValue(userId, out var u)) return false;
        lock (u) { u.OrdersCount++; }
        return true;
    }
}
