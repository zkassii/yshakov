using System.Text.Json;
using Confluent.Kafka;
using Microsoft.Extensions.Options;

namespace UserService;

// Consumer: order.created
public class OrderCreatedConsumer : BackgroundService
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private readonly KafkaOptions _options;
    private readonly UserStore _store;
    private readonly ILogger<OrderCreatedConsumer> _logger;

    public OrderCreatedConsumer(IOptions<KafkaOptions> options, UserStore store, ILogger<OrderCreatedConsumer> logger)
    {
        _options = options.Value;
        _store = store;
        _logger = logger;
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
        => Task.Run(() => Run(stoppingToken), stoppingToken);

    private void Run(CancellationToken ct)
    {
        var config = new ConsumerConfig
        {
            BootstrapServers = _options.BootstrapServers,
            GroupId = _options.GroupId,
            AutoOffsetReset = AutoOffsetReset.Earliest,
            EnableAutoCommit = false
        };

        using var consumer = new ConsumerBuilder<string, string>(config).Build();
        consumer.Subscribe(_options.ConsumeTopic);
        _logger.LogInformation("Подписка на {Topic}, группа {Group}", _options.ConsumeTopic, _options.GroupId);

        while (!ct.IsCancellationRequested)
        {
            try
            {
                var result = consumer.Consume(ct);
                if (result?.Message == null) continue;

                var order = JsonSerializer.Deserialize<OrderCreatedEvent>(result.Message.Value, Json);
                if (order != null)
                {
                    if (_store.IncrementOrders(order.UserId))
                        _logger.LogInformation("Заказ {OrderId} учтён для пользователя {UserId}", order.OrderId, order.UserId);
                    else
                        _logger.LogWarning("Заказ {OrderId}: пользователь {UserId} не найден", order.OrderId, order.UserId);
                }

                consumer.Commit(result);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "Некорректный JSON в order.created, сообщение пропущено");
            }
            catch (ConsumeException ex)
            {
                _logger.LogError("Ошибка Kafka: {Reason}", ex.Error.Reason);
                Thread.Sleep(2000);
            }
        }

        consumer.Close();
    }
}
