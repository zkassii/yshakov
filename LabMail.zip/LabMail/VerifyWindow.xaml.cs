using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using LabMail.Services;

namespace LabMail;

public partial class VerifyWindow : Window
{
    private readonly OtpService _otp;
    private readonly EmailService _mail;
    private readonly string _email;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };

    public VerifyWindow(OtpService otp, EmailService mail, string email)
    {
        InitializeComponent();
        _otp = otp; _mail = mail; _email = email;

        _timer.Tick += (_, _) => UpdateTimer();
        _timer.Start();
        UpdateTimer();
        Closed += (_, _) => _timer.Stop();
    }

    private void UpdateTimer()
    {
        var left = _otp.ExpiresAtUtc - DateTime.UtcNow;
        TimerText.Text = left > TimeSpan.Zero
            ? $"Код действителен ещё {left:mm\\:ss}"
            : "Срок действия кода истёк";
    }

    private void Show(string text, bool ok)
    {
        Info.Text = text;
        Info.Foreground = ok ? Brushes.Green : Brushes.Firebrick;
    }

    private void Confirm_Click(object sender, RoutedEventArgs e)
    {
        switch (_otp.Verify(CodeBox.Text.Trim()))
        {
            case OtpResult.Ok:
                MessageBox.Show(this, "Авторизация успешно выполнена!", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
                break;
            case OtpResult.Wrong:
                Show("Неверный код. Попробуйте ещё раз.", false); break;
            case OtpResult.Expired:
                Show("Срок действия кода истёк. Запросите новый код.", false); break;
            case OtpResult.AlreadyUsed:
                Show("Этот код уже был использован.", false); break;
            default:
                Show("Код ещё не был сгенерирован.", false); break;
        }
    }

    private async void Resend_Click(object sender, RoutedEventArgs e)
    {
        ResendBtn.IsEnabled = false;
        Show("Отправка...", true);

        var code = _otp.Generate();
        var (ok, msg) = await _mail.SendAsync(
            _email, "Код подтверждения", OtpService.BuildHtml(code), isHtml: true);

        Show(ok ? "Новый код отправлен." : msg, ok);
        if (ok) { CodeBox.Clear(); UpdateTimer(); }
        ResendBtn.IsEnabled = true;
    }
}
