using System.Security.Cryptography;

namespace LabMail.Services;

public enum OtpResult { Ok, Wrong, Expired, AlreadyUsed, NoCode }

public class OtpService
{
    public static readonly TimeSpan Lifetime = TimeSpan.FromMinutes(5);

    private string? _code;
    private bool _used;

    public DateTime ExpiresAtUtc { get; private set; }

    public string Generate()
    {
        _code = RandomNumberGenerator.GetInt32(0, 1_000_000).ToString("D6");
        ExpiresAtUtc = DateTime.UtcNow + Lifetime;
        _used = false;
        return _code;
    }

    public OtpResult Verify(string input)
    {
        if (_code is null) return OtpResult.NoCode;
        if (_used) return OtpResult.AlreadyUsed;
        if (DateTime.UtcNow > ExpiresAtUtc) return OtpResult.Expired;
        if (input != _code) return OtpResult.Wrong;
        _used = true;
        return OtpResult.Ok;
    }

    public static string BuildHtml(string code) => $@"
<div style='font-family:Segoe UI,Arial,sans-serif;max-width:420px;margin:auto;padding:24px;border:1px solid #ddd;border-radius:8px'>
  <h2 style='margin-top:0'>Код подтверждения</h2>
  <p>Ваш одноразовый код для входа:</p>
  <p style='font-size:34px;letter-spacing:8px;font-weight:bold;margin:16px 0'>{code}</p>
  <p>Код действителен в течение <b>{(int)Lifetime.TotalMinutes} минут</b> и может быть использован только один раз.</p>
  <p style='color:#888;font-size:12px'>Если вы не запрашивали код, просто проигнорируйте это письмо.</p>
</div>";
}
