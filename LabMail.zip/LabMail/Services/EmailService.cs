using System.Net.Sockets;
using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;

namespace LabMail.Services;

public class EmailService
{
    public async Task<(bool Ok, string Message)> SendAsync(
        string to, string subject, string body, bool isHtml = false)
    {
        try
        {
            var cfg = SmtpSettings.Load();

            var msg = new MimeMessage();
            msg.From.Add(new MailboxAddress(cfg.FromName, cfg.Login));
            msg.To.Add(MailboxAddress.Parse(to.Trim()));
            msg.Subject = subject;
            msg.Body = isHtml
                ? new BodyBuilder { HtmlBody = body }.ToMessageBody()
                : new TextPart("plain") { Text = body };

            var option = cfg.Security switch
            {
                "SslOnConnect" => SecureSocketOptions.SslOnConnect,
                "Auto" => SecureSocketOptions.Auto,
                _ => SecureSocketOptions.StartTls
            };

            using var client = new SmtpClient();
            client.Timeout = 15000;
            await client.ConnectAsync(cfg.Host, cfg.Port, option);
            await client.AuthenticateAsync(cfg.Login, cfg.Password);
            await client.SendAsync(msg);
            await client.DisconnectAsync(true);
            return (true, "Письмо успешно отправлено.");
        }
        catch (ParseException)
        {
            return (false, "Некорректный адрес электронной почты получателя.");
        }
        catch (AuthenticationException)
        {
            return (false, "Ошибка авторизации: неверный логин или пароль.");
        }
        catch (SslHandshakeException)
        {
            return (false, "Ошибка защищённого соединения. Проверьте порт и параметр Security.");
        }
        catch (SmtpCommandException ex)
        {
            return (false, $"Сервер отклонил команду: {ex.Message}");
        }
        catch (Exception ex) when (ex is SocketException or IOException or TimeoutException or OperationCanceledException)
        {
            return (false, "Не удалось подключиться к серверу. Проверьте Host, Port и сеть.");
        }
        catch (Exception ex)
        {
            return (false, "Ошибка: " + ex.Message);
        }
    }
}
