using System.IO;
using System.Text.Json;

namespace LabMail.Services;

public class SmtpSettings
{
    public string Host { get; set; } = "";
    public int Port { get; set; } = 587;
    public string Security { get; set; } = "StartTls"; // StartTls | SslOnConnect | Auto
    public string Login { get; set; } = "";
    public string Password { get; set; } = "";
    public string FromName { get; set; } = "Lab App";

    public static SmtpSettings Load()
    {
        var path = Path.Combine(AppContext.BaseDirectory, "smtp.settings.json");
        if (!File.Exists(path))
            throw new FileNotFoundException("Не найден файл настроек smtp.settings.json");
        return JsonSerializer.Deserialize<SmtpSettings>(File.ReadAllText(path))
               ?? throw new InvalidDataException("Файл настроек пуст");
    }
}
