Запуск: Visual Studio 2022 -> открыть LabMail.csproj -> F5 (нужен .NET 8 SDK, рабочая нагрузка ".NET desktop").
Либо: dotnet run
Настройки SMTP: smtp.settings.json (Host/Port/Security уточнить у преподавателя).
Security: StartTls (порт 587), SslOnConnect (порт 465) или Auto.
Не выкладывайте smtp.settings.json на GitHub (он в .gitignore).
