using System.Windows;

namespace LabMail;

public partial class App : Application
{
}
