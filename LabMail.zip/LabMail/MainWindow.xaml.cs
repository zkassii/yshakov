using System.Windows;
using System.Windows.Media;
using LabMail.Services;

namespace LabMail;

public partial class MainWindow : Window
{
    private readonly EmailService _mail = new();
    private readonly OtpService _otp = new();

    public MainWindow() => InitializeComponent();

    private void SetStatus(string text, bool ok)
    {
        StatusText.Text = text;
        StatusText.Foreground = ok ? Brushes.Green : Brushes.Firebrick;
    }

    private bool CheckEmail()
    {
        if (string.IsNullOrWhiteSpace(EmailBox.Text))
        {
            SetStatus("Введите адрес получателя.", false);
            return false;
        }
        return true;
    }

    // Пункт 5.1
    private async void Send_Click(object sender, RoutedEventArgs e)
    {
        if (!CheckEmail()) return;
        if (string.IsNullOrWhiteSpace(SubjectBox.Text) || string.IsNullOrWhiteSpace(BodyBox.Text))
        {
            SetStatus("Заполните тему и текст сообщения.", false);
            return;
        }

        SendBtn.IsEnabled = false;
        SetStatus("Отправка...", true);
        var (ok, msg) = await _mail.SendAsync(EmailBox.Text, SubjectBox.Text, BodyBox.Text);
        SetStatus(msg, ok);
        SendBtn.IsEnabled = true;
    }

    // Пункт 5.2
    private async void Code_Click(object sender, RoutedEventArgs e)
    {
        if (!CheckEmail()) return;

        CodeBtn.IsEnabled = false;
        SetStatus("Отправка кода...", true);

        var code = _otp.Generate();
        var (ok, msg) = await _mail.SendAsync(
            EmailBox.Text, "Код подтверждения", OtpService.BuildHtml(code), isHtml: true);

        SetStatus(ok ? "Код отправлен на " + EmailBox.Text.Trim() : msg, ok);
        CodeBtn.IsEnabled = true;

        if (ok)
        {
            // Пункт 5.3: переход к окну проверки
            new VerifyWindow(_otp, _mail, EmailBox.Text.Trim()) { Owner = this }.ShowDialog();
        }
    }
}
